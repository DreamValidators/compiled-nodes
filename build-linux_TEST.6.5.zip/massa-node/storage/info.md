This folder contains all stored data, its size may reach 1TB. The node needs read and write access to it.
