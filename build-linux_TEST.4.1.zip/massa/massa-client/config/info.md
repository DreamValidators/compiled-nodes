This folder contains all client-related user config data.
